# RiskyCoin Documentation Draft

RiskyCoin の Docusaurus 用ドキュメント草案です。

## 収録内容

- `docs/risky-coin/`
  - `overview.md`
  - `setup.md`
  - `settings.md`
  - `troubleshooting.md`
  - `_category_.json`
- `static/img/risky-coin/`
  - 提供された JPG 画像 26 枚
- `ready-to-copy/`
  - 現在の `lura-world-doc` 構成をもとに RiskyCoin を追加した関連ファイル
- `integration/REPO_CHANGES.diff`
  - サイドバー、ナビゲーション、トップカード、intro の変更差分
- `IMAGE_USAGE.md`
  - 各画像をどこに使うかの一覧

## 組み込み手順

1. `docs/risky-coin` を、リポジトリの `docs/` へコピー
2. `static/img/risky-coin` を、リポジトリの `static/img/` へコピー
3. `integration/REPO_CHANGES.diff` を確認し、次のファイルへ変更を反映
   - `sidebars.js`
   - `docusaurus.config.js`
   - `src/components/HomepageFeatures/index.js`
   - `docs/intro.md`
4. ローカルで `npm run build` を実行し、リンク切れと画像パスを確認
5. 問題がなければ公開

`ready-to-copy` 内には上記 4 ファイルの完成案もあります。リポジトリ側に追加変更がある場合は、そのまま上書きせず差分を確認してください。

## 構成方針

1 ページへすべて詰め込まず、購入者が必要な順に分けています。

1. 概要：何が起きるギミックか、Safe / Danger の違い
2. セットアップ：インポート、Prefab 選択、位置調整
3. 設定：4 種類の基本設定、Level、Save Data
4. FAQ：TMP、Orb、Progress、配置、Quest
