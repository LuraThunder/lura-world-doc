# 画像使用計画

提供された 26 枚すべてに用途を割り当てています。

| 画像 | 使用ページ | 役割 |
|---|---|---|
| `MainThumb.jpg` | 概要・サイトトップ | メインサムネイル、RiskyCoin カード画像 |
| `ProjectPanel_ImportRiskyCoin.jpg` | セットアップ | インポート完了後のフォルダ確認 |
| `TextMeshPro.jpg` | セットアップ・FAQ | TMP Essentials の導入 |
| `ProjectPanel_MainPrefab.jpg` | セットアップ | SafeMode / DangerMode の Prefab 選択 |
| `RiskyCoin_SafeMode.jpg` | 概要・セットアップ | SafeMode の説明 |
| `RiskyCoin_DangerMode.jpg` | 概要・セットアップ | DangerMode の説明 |
| `Hierarcy_RiskyCoin.jpg` | セットアップ | RiskyCoin 本体の選択箇所 |
| `SceneView_Selection_RiskyCoin_.jpg` | セットアップ | RiskyCoin の配置調整 |
| `Hierarcy_Jail.jpg` | セットアップ | Jail の選択箇所 |
| `SceneView_Selection_Jail.jpg` | セットアップ | Jail の配置調整 |
| `SceneView_Jails.jpg` | セットアップ | Jail 全体の大きさ・空間確認 |
| `Hierarcy_Boards.jpg` | セットアップ | 2 種類の Board の選択箇所 |
| `SceneView_Boards.jpg` | セットアップ | Board の配置調整 |
| `SceneView_RiskyCoinAndBoards.jpg` | セットアップ | 配置完了例 |
| `ProjectPanel_RiskyCoinSample.jpg` | セットアップ | Sample Scene の場所 |
| `Hierarcy_All.jpg` | セットアップ | Sample Scene が両 Mode を含むことの説明 |
| `RiskyCoin_Board.jpg` | 概要 | Board の表示内容 |
| `Inspector_RiskyCoin_All.jpg` | 設定 | 基本設定全体と折りたたみ項目 |
| `Inspector_RiskyCoin_EventStreakRules.jpg` | 設定 | 連勝・連敗条件 |
| `Inspector_RiskyCoin_EventWeight.jpg` | 設定 | Orb Weight と反転確率 |
| `Inspector_RiskyCoin_RewardDuration.jpg` | 設定 | Key / Shield の有効時間 |
| `Inspector_RiskyCoin_Time.jpg` | 設定 | 初期収監時間 |
| `Hierarcy_MainBoard.jpg` | 設定 | Level 設定対象の選択 |
| `Inspector_RiskyCoin_LVControl.jpg` | 設定 | Level 必要勝利数 |
| `Hierarcy_SaveData.jpg` | 設定 | SaveData の選択 |
| `Inspector_RiskyCoin_SaveData.jpg` | 設定 | Save Key と Progress リセット注意 |

## 配置方針

- 導入手順では、Hierarchy の小さい画像と Scene ビューを横並びにする
- SafeMode / DangerMode は概要ページでは別々に大きく見せる
- Inspector の切り抜き画像は、該当する説明の直前に置く
- `Inspector_RiskyCoin_All.jpg` は全項目の説明に使わず、「どこを触るか」の全体図として使う
- Sample Scene の 2 枚は本編の必須手順から分離し、任意確認として末尾へ置く
