---
sidebar_position: 4
---

# よくある質問

## Board や Jail 内のテキストが表示されない

TextMeshPro Essentials が未導入の可能性があります。

1. Unity の **Window → TextMeshPro → Import TMP Essential Resources** を実行する
2. **Import TMP Essentials** を押す
3. 使用中のシーンを開き直す

<div class="doc-media doc-media--left doc-media--full">
  <img src="/lura-world-doc/img/risky-coin/TextMeshPro.jpg" alt="Import TMP Essentials" width="624" />
</div>

## Missing Script や UdonSharp のエラーが表示される

RiskyCoin は、VCC で作成した **VRChat Worlds プロジェクト**へ導入してください。

Avatar プロジェクトや、VRChat SDK / UdonSharp が入っていない通常の Unity プロジェクトでは動作しません。

既存プロジェクトの依存関係が壊れている場合は、VCC から新しい Worlds プロジェクトを作成し、RiskyCoin だけを導入して切り分けてください。

## 3連敗しても Orb が発生しない

SafeMode では正常な動作です。

SafeMode の標準設定では、次の値が `0` になっています。

- `Chase Weight`
- `Slash Weight`
- `Reverse Chance`

3連敗で攻撃 Orb を発生させる場合は DangerMode を使用するか、RiskyCoin Inspector で Chase / Slash の Weight を設定してください。

## 3連勝しても Orb が反転しない

次のいずれかを確認してください。

- SafeMode を使用している
- `Reverse Chance` が `0`
- `Chase Weight` と `Slash Weight` が両方 `0`
- インスタンス内で最初に発生した連勝 Orb である

標準仕様では、DangerMode でも最初の連勝 Orb は反転しません。

## 3連勝の報酬が攻撃 Orb へ変わった

DangerMode の標準動作です。

`Reverse Chance` の標準値は `0.5` で、2 回目以降の連勝イベントでは Shield / Key が Chase / Slash へ反転する可能性があります。

反転させたくない場合は、`Reverse Chance` を `0` にしてください。

## Orb が同じ種類ばかり出る

Weight の値を確認してください。

Weight は相対値なので、たとえば `Shield 10 / Key 1` にすると Shield が大幅に選ばれやすくなります。均等にしたい場合は同じ値にします。

`0` にした種類は抽選されません。

## Key や Shield が途中で消える

設定された有効時間が終了すると消滅します。

- `Key Duration Seconds`：未使用の Key が存在できる時間
- `Shield Duration Seconds`：Shield が有効な時間

RiskyCoin Inspector の **報酬の有効時間**から変更できます。

## 累計勝敗や Level が保存されない

PlayerObject Persistence を含む最終動作は、Unity の通常 Play Mode だけではなく、アップロードしたテストワールドでも確認してください。

また、Hierarchy の `System > SaveData` にある Save Key が標準値から変更されていないか確認します。

## Progress が 0 に戻った

Save Key を変更すると、新しい Progress として開始します。

標準値は次のとおりです。

`RiskyCoin.Progress.v1`

以前の値へ戻しても、すでに新しいキーで保存処理が行われたあとの復旧を保証するものではありません。公開後は変更しないでください。

## Level 条件を変えたらプレイヤーの Level が変わった

Level は保存された数値ではなく、累計勝利数と現在の Level 条件から計算されます。

そのため、公開後に `LV1 Required Wins` などを変更すると、保存済みの累計勝利数は維持されたまま、Level が新しい条件で再判定されます。

## コインが拾えない、またはすぐ手から離れる

Orb イベント中やトスの判定中は、同期を保つため Pickup が一時的に制限されます。イベント終了後に再度確認してください。

常に拾えない場合は、次を確認します。

- RiskyCoin が床や Collider にめり込んでいない
- Prefab 内の `VRC Pickup` や `VRC Object Sync` を削除していない
- SafeMode と DangerMode を同じシーンへ同時に置いていない

## Jail へ移動したときに他の空間と重なる

Hierarchy の `Jail` を選択し、ワールド本体と重ならない空きスペースへ移動してください。

Jail 内には複数の判定範囲が含まれるため、子オブジェクトを個別に移動せず、`Jail` のルートを移動します。

## 中の人の声が外へ聞こえない

仕様です。

- Outside → Inside：聞こえる
- Inside → Outside：聞こえない
- Inside → Inside：聞こえる
- Outside → Outside：通常どおり聞こえる

## Sample Scene と同じように 2 つ配置してよい？

Sample Scene は SafeMode と DangerMode の比較用です。

実際のワールドには、使用する Main Prefab を 1 つだけ配置してください。

## Quest で動作する？

Quest 対応は未検証です。Quest 向けとして公開する場合は、シェーダー、描画負荷、Udon 動作、UI 表示を実機で個別に検証してください。

## 導入後に触らないほうがよい項目

通常は、次の項目を変更しないでください。

- `詳細設定 / Advanced`
- `同期状態 / Network State`
- `内部参照 / System References`
- Prefab 内の `System` 配下
- 各 UdonSharp Behaviour の参照先

基本的なカスタマイズは、`RiskyCoin` と `RiskyCoin_Board` の専用 Inspector だけで完結します。
