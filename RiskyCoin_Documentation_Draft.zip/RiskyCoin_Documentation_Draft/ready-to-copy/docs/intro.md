---
sidebar_position: 2
---

# ホーム

Lura World Docs は、VRChat 向けに制作したワールド・ギミックアセットの導入手順とカスタマイズ方法をまとめるためのドキュメントサイトです。

現在、次のガイドを掲載しています。

- [LuminousHotel 解説](./luminous-hotel/overview.md)
- [LuminousOasis 解説](./luminous-oasis/overview.md)
- [RiskyCoin 解説](./risky-coin/overview.md)

## このサイトの使い方

各アセットの導入、初期設定、調整項目、トラブル対応を、購入後に必要になる順番で整理しています。

## 現在の構成

### LuminousHotel

- ようこそ
- セットアップと導入
- シーン初期設定
- アップロードと Quest 対応
- トラブルシューティング

### LuminousOasis

- セットアップと導入
- シーン初期設定
- アップロード
- ギミック解説
- トラブルシューティング

### RiskyCoin

- ギミック概要と SafeMode / DangerMode
- UnityPackage のインポートと配置
- 連勝・連敗、Orb、収監時間、Level の設定
- Save Data とトラブルシューティング

## RiskyCoin を導入する

1. [RiskyCoin クイックスタートガイド](./risky-coin/overview.md)
2. [セットアップと配置](./risky-coin/setup.md)
3. [ルールと Level の設定](./risky-coin/settings.md)

