// @ts-check

// This runs in Node.js - Don't use client-side code here (browser APIs, JSX...)

/**
 * Creating a sidebar enables you to:
 - create an ordered group of docs
 - render a sidebar for each doc of that group
 - provide next/previous navigation

 The sidebars can be generated from the filesystem, or explicitly defined here.

 Create as many sidebars as you want.

 @type {import('@docusaurus/plugin-content-docs').SidebarsConfig}
 */
const sidebars = {
  luminousHotelSidebar: [
    'luminous-hotel/overview',
    'luminous-hotel/setup',
    'luminous-hotel/scene-settings',
    'luminous-hotel/upload',
    'luminous-hotel/troubleshooting',
  ],
  luminousOasisSidebar: [
    'luminous-oasis/overview',
    'luminous-oasis/setup',
    'luminous-oasis/scene-settings',
    'luminous-oasis/upload',
    'luminous-oasis/troubleshooting',
    'luminous-oasis/gimmicks',
  ],
  riskyCoinSidebar: [
    'risky-coin/overview',
    'risky-coin/setup',
    'risky-coin/settings',
    'risky-coin/troubleshooting',
  ],
};

export default sidebars;
